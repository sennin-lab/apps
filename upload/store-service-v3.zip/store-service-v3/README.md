# store-service v3（sorachat と同じポイントの仕組み）

仙人アカウントでログインし、仙人ポイントで買えるアプリの配信サービスです。
アプリ内課金・ポイント配布・作者への売上は、sorachat（senninstudio）と同じ考え方で動きます。

## 構成
- `public/index.html` … ホーム（入手したアプリを並べる）
- `public/store.html` … ストア（購入・レビュー・コード引き換え）
- `public/run.html` … アプリ実行画面（許可の確認・支払いの確認シート・アプリへの橋渡し）
- `public/studio.html` … senninstudio for apps（アプリの公開・売上・配布・管理者）
- `server.js` … 仙人アカウント（OAuth/PKCE）、購入、アプリ内課金、ポイント配布、売上、API
- `lib/rules.js` … 点数の上限・依頼の確認・失敗の分類（テストできる純粋な関数）
- `lib/crypto.js` … 仙人アカウントの更新トークンの暗号化（AES-256-GCM）
- `supabase/schema.sql` … 新規作成用（既存テーブルを削除します）
- `supabase/migration_v3_points.sql` … 既存DBに追加するSQL（データは消えません）

## セットアップ
1. **Supabase**
   - 新規: `schema.sql` → `migration_v3_points.sql` の順に実行。
   - 既存（v2）: `migration_v3_points.sql` だけを実行。
2. **Turso**: 従来どおり（画像保存、起動時に自動作成）。
3. **仙人アカウントにアプリを登録**（開発者設定）
   - リダイレクトURI: `${PUBLIC_URL}/auth/callback`
   - スコープ: `profile email points:read points:write`（`points:write` は仙人アカウント側の管理者の承認が必要）
4. 環境変数を設定（`.env.example` 参照）。`TOKEN_ENCRYPTION_KEY` は必須です（`openssl rand -hex 32`）。
5. 管理者: 一度ログインし、studio に表示される自分のIDを `ADMIN_SUBS` に設定して再起動。
6. 自分のアプリにも支払い・購入をさせるなら、運営のアカウントの sub を `OPERATOR_SUB` に設定（未設定だと、自分のアプリは有料にできません）。

既存の利用者は、v3 のあと一度ログインし直すと、ポイントの連携が作られます。

## ポイントの流れ（sorachat と同じ）

### アプリ内課金（`window.senninapp.charge`）
- アプリが `charge(金額, 品名)` を呼ぶと、ホームに確認画面が出ます。利用者が「支払う」を押したときだけ払われます。
- 金額は 10〜1,000pt（認定開発者は 5,000pt まで）。確認画面に出た金額と品名が、そのまま払われます。
- 支払いは「予約 → 仙人アカウントで減算 → 確定」の順で記録します。同じ `requestId` で押し直しても二重には払いません。
- 確実に失敗したもの（残高不足・許可なし・上限超えなど）は失敗として閉じます。結果が分からない通信の失敗は、同じ `requestId` で確かめ直せるように予約を残します。

### ポイント配布（`window.senninapp.award`）
- 管理者が、アプリごとに「合計の上限」「1回の上限」「1人が1分間に受け取れる上限」を決めます（studio の管理者パネル）。
- 利用者の許可（名前などを渡すことへの同意）が必要です。配布を持つアプリは、初めて開くときに許可を求めます。
- 上限の確認と枠の確保は、データベースの関数（`app_award_reserve`）で行います。同じ `requestId` の押し直しは二重に加算しません。

### 作者への売上
- 購入・支払いのたびに、作者へ全額（手数料なし）を払う売上を作ります。
- 作者が仙人アカウントと連携していなければ「支払い待ち」のまま残り、連携したときや定期的な再送で払われます。
- 売上は studio の「売上・ポイント配布」で確認できます。

## 開発者向けの仕様
studio の「アプリの仕様」（`/api/studio/spec`）に、`window.senninapp` の使い方と失敗の code をまとめています。

## 既知の制限
- 返金は未実装です。払ったポイントの取り消しは、現状では管理者が個別に対応する前提です。
- 利用者の許可の取り消しは API（`DELETE /api/apps/:id/consent`）のみで、画面にはまだありません。
- 1分あたりの回数制限はプロセス内で行うため、複数インスタンスでは別途対策が必要です。
- 旧版の SKU 型のアプリ内課金（`iap_products`、`/api/iap/*`）は、v3 では使いません。テーブルは残しています（不要なら削除してかまいません）。
- sorachat にある SenninBank（株主配当）とサービス内の別機能は、この版には移植していません。
- 画像は1枚2MB以下（jpg/png/webp）。HTMLは2MB以下です。
- `SENNIN_BASE` は既定で Cloudflare Workers の URL を使います。

## テスト
- `node --test test/rules.test.mjs` … 点数ルール・分類・暗号化の単体テスト（DB 不要）
